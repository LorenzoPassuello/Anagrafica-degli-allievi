﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentiApp
{
    class Elenco
    {
        private List<Studenti> elenco;
        public Elenco()
        {
            elenco = new List<Studenti>();
        }

        public void add(Studenti s)
        {
            elenco.Add(s);
        }

        public List<Studenti> getElenco()
        {
            return elenco;
        }
    }
}
