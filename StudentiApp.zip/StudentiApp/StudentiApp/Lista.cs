﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentiApp
{
    class Lista
    {
        public string nome { get; set; }
        public string cognome { get; set; }
        public string luogoNascita { get; set; }
        public string dataNascita { get; set; }
        public string codiceFiscale { get; set; }
        public string classe { get; set; }

    }
}
