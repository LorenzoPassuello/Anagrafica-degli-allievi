﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentiApp
{
    class Studenti
    {
        private string nome;
        private string cognome;
        private string luogoNascita;
        private string dataNascita;
        private string codiceFiscale;
        private string classe;

        public Studenti(string nome_in, string cognome_in, string luogoNascita_in, string dataNascita_in, string codiceFiscale_in, string classe_in)
        {
            this.nome = nome_in;
            this.cognome = cognome_in;
            this.luogoNascita = luogoNascita_in;
            this.dataNascita = dataNascita_in;
            this.codiceFiscale = codiceFiscale_in;
            this.classe = classe_in;
        }

        public string getNome()
        {
            return this.nome;
        }
        public string getCognome()
        {
            return this.cognome;
        }
        public string getLuogoNascita()
        {
            return this.luogoNascita;
        }
        public string getDataNascita()
        {
            return this.dataNascita;
        }
        public string getCodiceFiscale()
        {
            return this.codiceFiscale;
        }
        public string getClasse()
        {
            return this.classe;
        }

    }
}
